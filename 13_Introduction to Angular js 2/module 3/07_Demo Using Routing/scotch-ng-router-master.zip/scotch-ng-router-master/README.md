## Scotch Angular Component Router Tutorial Demo

This is a demo to support a Scotch article. Read the article alongside with playing with the demo for better understanding.

To run, clone the demo and run:

```bash
# Install dependncies
npm install
# Start app
npm start
```