export class Pet {
  name: string;
  age: number;
}
