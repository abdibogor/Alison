exports.default = () => tree => tree.create('/ng-add-test', 'hello world');
