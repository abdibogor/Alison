exports.default = (options) => tree => tree.create(options.name || 'empty-file', '');
