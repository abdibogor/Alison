<!-- Links in /docs/documentation should NOT have \`.md\` at the end, because they end up in our wiki at release. -->

# ng run

## Overview
Runs Architect targets.

## Options
<details>
  <summary>configuration</summary>
  <p>
    <code>--configuration</code> (alias: <code>-c</code>)
  </p>
  <p>
    Specify the configuration to use.
  </p>
</details>
