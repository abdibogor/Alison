<!-- Links in /docs/documentation should NOT have `.md` at the end, because they end up in our wiki at release. -->

# ng generate class

## Overview
`ng generate class [name]` generates a class

## Options
<details>
  <summary>dry-run</summary>
  <p>
    <code>--dry-run</code> (alias: <code>-d</code>)
  </p>
  <p>
    Run through without making any changes.
  </p>
</details>
<details>
  <summary>force</summary>
  <p>
    <code>--force</code> (alias: <code>-f</code>)
  </p>
  <p>
    Forces overwriting of files.
  </p>
</details>
<details>
  <summary>project</summary>
  <p>
    <code>--project</code>
  </p>
  <p>
    The name of the project.
  </p>
</details>
<details>
  <summary>spec</summary>
  <p>
    <code>--spec</code>
  </p>
  <p>
    Specifies if a spec file is generated.
  </p>
</details>
<details>
  <summary>type</summary>
  <p>
    <code>--type</code>
  </p>
  <p>
    Specifies the type of class.
  </p>
</details>
